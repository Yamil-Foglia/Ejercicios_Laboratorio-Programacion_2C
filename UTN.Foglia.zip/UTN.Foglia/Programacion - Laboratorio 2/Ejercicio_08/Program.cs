﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_08
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 08";
            /*
            int valorHora;
            string nombre; 
            int antiguedad;
            int i;

            Console.WriteLine("Valor de hora:  ");
            while (!(int.TryParse(Console.ReadLine(), out valorHora)))
            {
                Console.WriteLine("ERROR - Valor de hora: ");
                Console.ReadKey();
            }

    */

        }
    }
}
