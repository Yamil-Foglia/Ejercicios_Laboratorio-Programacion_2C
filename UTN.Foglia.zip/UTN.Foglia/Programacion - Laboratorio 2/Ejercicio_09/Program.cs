﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_09
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 09";

            int altura;
            int contador = 0;
            int i;
            int j;
        
            Console.WriteLine("Altura de piramide: ");
            while (!(int.TryParse(Console.ReadLine(), out altura)))
            {
                Console.WriteLine("ERROR - Altura de piramide: ");
                Console.ReadKey();
            }

            for(i=0; i<altura; i++)
            {
                for (j=0;  j<=contador; j++)
                {
                    Console.Write("*");
                }
                Console.Write("\n");
                contador+=2;
            }
            Console.ReadKey();
        }
    }
}
