﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tinta
{
    class Boligrafo
    {
        public const short cantidadTintaMaxima = 100;
        public ConsoleColor color;
        public short tinta;
        
        public Boligrafo()
        {
            this.color = 0;
            this.tinta = 0;
        }

        public ConsoleColor GetColor()
        {
            return this.color;
        }

        public short GetTinta()
        {
            return this.tinta;
        }

        private void SetTinta(short tinta)
        {
            int tintaActual = (int)this.tinta;

            tintaActual = tintaActual + (int)tinta;

            if(tintaActual >=0 && tintaActual <= cantidadTintaMaxima)
            {
                this.tinta = (short)tintaActual;
            }
        }

        public void Recargar()
        {
            SetTinta(cantidadTintaMaxima);
        }

        public bool Pintar(short gasto, out string dibujo)
        {
            int i;
            dibujo = "";

            bool respuesta = false;

            if (this.tinta > 0)
            {
                for (i = 0; i < gasto; i++)
                {
                    if (this.tinta > 0)
                    {
                        dibujo = dibujo + "*";
                        SetTinta(-1);
                    }
                }
                respuesta = true;
            }
            return respuesta;
        }




    }

}
