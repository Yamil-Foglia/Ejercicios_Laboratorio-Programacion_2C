﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tinta;

namespace Ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 17";

            Boligrafo boligrafoAzul = new Boligrafo();
            Boligrafo boligrafoRojo = new Boligrafo();
            string dibujo;

            boligrafoAzul.color = ConsoleColor.Blue;
            boligrafoAzul.tinta = 100;

            boligrafoRojo.color = ConsoleColor.Red;
            boligrafoRojo.tinta = 50;

            try
            {
                Console.WriteLine("Azul");
                if (boligrafoAzul.Pintar(500, out dibujo))
                {
                    Console.ForegroundColor = boligrafoAzul.color;
                    Console.WriteLine(dibujo);
                    Console.Write(boligrafoAzul.GetTinta());
                    Console.ReadKey();
                }
                else
                {
                    throw new Exception("Boligrado sin tinta");
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            try
            {
                Console.WriteLine("Rojo");
                if (boligrafoRojo.Pintar(50, out dibujo))
                {
                    Console.ForegroundColor = boligrafoRojo.color;
                    Console.WriteLine(dibujo);
                    Console.ReadKey();
                }
                else
                {
                    throw new Exception("Boligrado sin tinta");
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
