﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleKeyInfo signo;

            double numUno = 0;
            double numDos = 0;
            double? resultado= 0; 

            try
            {
                Console.WriteLine("Numero 1: ");
                numUno = double.Parse(Console.ReadLine());

                Console.WriteLine("Numero 2: ");
                numDos = double.Parse(Console.ReadLine());

                
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.Message);

                Console.ReadLine();
            }
            Console.WriteLine("Ingrese el signo de la operacion que desea realizar: ");
            signo = Console.ReadKey();

            
            resultado = Calculadora.calcular(numUno, numDos, signo.KeyChar);
            if(resultado == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n\nError !!!");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n\nResultado: {0}", resultado);
            }

            Console.ReadLine();

        }
    }
}
