﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    public static class Calculadora
    {
        public static double? calcular(double num1, double num2, char signo)
        {
            double? resultado = null; 

            if(signo == '+')
            {
                resultado = num1 + num2; 
            }
            else if(signo == '-')
            {
                resultado = num1 - num2;
            }
            else if (signo == '*')
            {
                resultado = num1 * num2;
            }
            else if (signo == '/')
            {
                try
                {
                    if (Calculadora.validar(num2))
                    {
                        throw new Exception("\n\n\n Al intentar dividir por 0 se produce un error.");
                    }
                    resultado = num1 / num2;
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(ex.Message);
                }
            }

            return resultado;
        }

        private static bool validar(double num2)
        {
            bool respuesta;

            if(num2 == 0)
            {
                respuesta = true;
            }
            else
            {
                respuesta = false;
            }

            return respuesta;
        }

    }
}
