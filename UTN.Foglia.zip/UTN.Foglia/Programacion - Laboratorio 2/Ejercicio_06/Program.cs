﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_06
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 06";

            int añoDeInicio;
            int añoDeFin;
            int i;
            int contador = 0;

            Console.WriteLine("Año de inicio: ");
            while (!(int.TryParse(Console.ReadLine(), out añoDeInicio)))
            {
                Console.WriteLine("ERROR - Año de inicio: ");
                Console.ReadKey();
            }

            Console.WriteLine("Año de fin: ");
            while (!(int.TryParse(Console.ReadLine(), out añoDeFin)))
            {
                Console.WriteLine("ERROR - Año de fin: ");
                Console.ReadKey();
            }

            for(i=añoDeInicio; i<añoDeFin; i++)
            {
                if(i % 4 == 0)
                {
                    if (i % 400 == 0)
                    {
                        contador++;
                        Console.WriteLine("Año bisiesto numero {0} : {1}", contador, i);
                        continue;
                    }
                    else if (i % 100 == 0)
                    {
                        continue;
                    }
                    contador++;
                    Console.WriteLine("Año bisiesto numero {0} : {1}", contador, i);
                }
            }
            Console.ReadKey();
        }
    }
}
