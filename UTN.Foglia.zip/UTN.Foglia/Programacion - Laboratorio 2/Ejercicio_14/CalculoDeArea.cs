﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    public static class CalculoDeArea
    {
        public static double calcularCuadrado(double numero)
        {
            double area;
            area = Math.Pow(numero, 2);

            return area; 

        }
        public static double calcularTriangulo(double b, double h)
        {
            double area;
            area = (b * h) / 2;

            return area;

        }
        public static double calcularCirculo(double radio)
        {
            double area;
            area = 3.14 * (Math.Pow(radio, 2));

            return area;

        }

    }
}
