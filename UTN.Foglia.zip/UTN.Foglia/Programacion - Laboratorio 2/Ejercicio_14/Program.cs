﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 14";
            int opcion = 0;
            double area;

            try
            {
                Console.WriteLine("Menu de opciones - Calcular area de...\n");
                Console.WriteLine("1 - Cuadrado");
                Console.WriteLine("2 - Triangulo");
                Console.WriteLine("3 - Circulo");
                Console.WriteLine("\nintroduzca la opcion numerica: ");

                opcion = int.Parse(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.Message);
            }
            
            switch(opcion)
            {
                case 1:

                    double lado;
                    Console.Clear();
                    try
                    {
                        Console.WriteLine("Medida de un solo lado del cuadrado: ");
                        lado = double.Parse(Console.ReadLine());

                        area = CalculoDeArea.calcularCuadrado(lado);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("\nEl area del cuadrado es {0}", area);
                    }
                    catch (Exception ex)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(ex.Message);
                    }
                    break;

                case 2:

                    double bas = 0;
                    double altura = 0;
                    Console.Clear();

                    try
                    {
                        Console.WriteLine("Medida de la base del triangulo: ");
                        bas = double.Parse(Console.ReadLine());
                        Console.WriteLine("Medida de la altura del triangulo: ");
                        altura = double.Parse(Console.ReadLine());

                        area = CalculoDeArea.calcularTriangulo(bas, altura);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("\nEl area del triangulo es {0}", area);
                    }
                    catch(Exception ex)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(ex.Message);
                    }
                    break;

                case 3:

                    double radio;
                    Console.Clear();

                    try
                    {
                        Console.WriteLine("Medida del radio del circulo: ");
                        radio = double.Parse(Console.ReadLine());

                        area = CalculoDeArea.calcularCirculo(radio);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("\nEl area del circulo es {0}", area);
                    }
                    catch (Exception ex)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(ex.Message);
                    }
                    break;

                default:

                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n\nOpcion incorrecta...");
                    break;

            }

            Console.ReadKey();
        }
    }
}
