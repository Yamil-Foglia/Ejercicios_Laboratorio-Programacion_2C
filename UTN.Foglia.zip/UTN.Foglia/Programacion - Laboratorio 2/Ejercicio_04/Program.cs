﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 04";
            int i;
            int j;
            int numero = int.MaxValue;
            int acumulador = 0;

            for (i = 0; i < numero; i++)
            {
                for (j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        acumulador = acumulador + j;
                    }
                }
                if(i == acumulador && i != 0 && i<8130)
                {
                    Console.WriteLine("{0}", i);
                    acumulador = 0;
                }
                acumulador = 0;
            }
            Console.ReadLine();
        }
    }
    
}
