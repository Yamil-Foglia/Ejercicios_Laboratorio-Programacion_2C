﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_19
{
    class Sumador
    {
        private int cantidadSumas;

        public Sumador(int cantidadSumas)
        {
            this.cantidadSumas = cantidadSumas;
        }

        public Sumador() : this(0)
        {
        }

        public long Sumar(long a, long b)
        {
            long resultado = a + b;
            this.cantidadSumas++;

            return resultado;
        }
        public string Sumar(string a, string b)
        {
            string resultado = a + b;
            this.cantidadSumas++;

            return resultado;
        }

        public int CantidadDeSumas()
        {
            return this.cantidadSumas;
        }

        public static long operator +(Sumador cantidadDeSumasActuales, int cantidadDeSumasAgregadas)
        {
            cantidadDeSumasActuales.cantidadSumas = cantidadDeSumasActuales.cantidadSumas + cantidadDeSumasAgregadas;

            return (long)cantidadDeSumasActuales.cantidadSumas;
        }

        public static bool operator |(Sumador sumador1, Sumador sumador2)
        {
            if (sumador1.cantidadSumas == sumador2.cantidadSumas)
                return true;
            return false;
        }


    }
}
