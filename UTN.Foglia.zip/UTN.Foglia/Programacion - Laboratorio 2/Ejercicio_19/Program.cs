﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_19
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 19";

            Sumador suma1 = new Sumador();

            Sumador suma2 = new Sumador(0);

            Console.WriteLine(suma1.Sumar(32, 32));
            Console.WriteLine(suma1.Sumar("\nHola ", "Mundo"));
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\nCantidad de sumas del primer sumador: {0}",suma1.CantidadDeSumas());
            Console.ReadLine();

            Console.WriteLine("Cantidad de sumas del segundo sumador + 4 sumas: {0}", suma2 + 4);
            Console.ReadLine();

            if(suma1|suma2)
            {
                Console.WriteLine("La cantidad de sumas de ambos sumadores son iguales");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("La cantidad de sumas de ambos sumadores NO son iguales");
            }

            Console.ReadLine();



        }
    }
}
