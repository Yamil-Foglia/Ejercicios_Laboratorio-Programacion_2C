﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 03";

            int numero;
            int i;
            int j;
            int flag = 1;

            while (flag == 1)
            {
                Console.WriteLine("Numero: ");

                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    Console.WriteLine("Exito - Numero ingresado {0}", numero);

                    for (i = 2; i <= numero; i++)
                    {
                        for(j = 2; j<=i; j++)
                        {
                            if (i % j == 0)
                            {
                                if (i == j)
                                {
                                    Console.WriteLine("{0}", i);
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                    Console.ReadKey();
                    flag = 0;
                }
                else
                {
                    Console.WriteLine("ERROR. ¡Reingresar número!");
                }
            }
        }
    }
}
