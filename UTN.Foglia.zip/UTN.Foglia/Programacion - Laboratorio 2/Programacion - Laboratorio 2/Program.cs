﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 01";

            int[] numeros = new int[5];
            string aux;
            int contador = 0;
            int acumulador = 0;
            int promedio = 0;
            int min = int.MaxValue;
            int max = int.MinValue;

            while (contador < 5)
            {
                Console.WriteLine("Numero {0}:", contador + 1);
                aux = Console.ReadLine();
                Console.Clear();

                if (int.TryParse(aux, out numeros[contador]))
                {
                    Console.WriteLine("Numero ingresado: {0}", numeros[contador]);

                    if (numeros[contador] < min)
                    {
                        min = numeros[contador];
                    }

                    if (numeros[contador] > max)
                    {
                        max = numeros[contador];
                    }

                    acumulador = acumulador + numeros[contador];
                    contador++;
                }
                else
                {
                    Console.WriteLine("Error.");
                }
            }

            promedio = acumulador / contador;

            Console.WriteLine("El maximo es {0} y el minimo es {1}", max, min);
            Console.WriteLine("El promedio es {0}", promedio);
            Console.ReadKey();
        }
    }
}
