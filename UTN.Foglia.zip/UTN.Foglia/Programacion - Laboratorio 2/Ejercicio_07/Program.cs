﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_07
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 07";

            int dia;
            int mes;
            int año;

            Console.WriteLine("dia: ");
            while (!(int.TryParse(Console.ReadLine(), out dia)))
            {
                Console.WriteLine("ERROR - Dia: ");
                Console.ReadKey();
            }
            Console.WriteLine("mes: ");
            while (!(int.TryParse(Console.ReadLine(), out mes)))
            {
                Console.WriteLine("ERROR - Mes: ");
                Console.ReadKey();
            }
            Console.WriteLine("año: ");
            while (!(int.TryParse(Console.ReadLine(), out año)))
            {
                Console.WriteLine("ERROR - Año: ");
                Console.ReadKey();
            }

            DateTime fechaDeNacimiento = new DateTime(año, mes, dia);

            TimeSpan antiguedad = DateTime.Now - fechaDeNacimiento;

            Console.WriteLine("Cantidad de dias vividos: {0}",antiguedad.Days);
            Console.ReadKey();
        }
    }
}
