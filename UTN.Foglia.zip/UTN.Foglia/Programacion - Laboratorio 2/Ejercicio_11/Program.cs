﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ejercicio Nro 11";
            int numero;
            int max = 100;
            int min = -100;
            int contador = 0;

            do
            {
                Console.WriteLine("Numero {0}: ", contador +1 );
                while (!(int.TryParse(Console.ReadLine(), out numero)))
                {
                    Console.WriteLine("ERROR - Numero: ");
                    Console.ReadKey();
                }

                if (Clases.validar(numero, min, max))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("El numero ingresado se encuentra entre los valores de maximo y minimo !!");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("El numero ingresado  no se encuentra entre los valores de maximo y minimo !!");
                    Console.ForegroundColor = ConsoleColor.White;
                    contador--;
                }
                contador++;
            } while (contador < 10);
            Console.ReadKey();
        }
    }
}
