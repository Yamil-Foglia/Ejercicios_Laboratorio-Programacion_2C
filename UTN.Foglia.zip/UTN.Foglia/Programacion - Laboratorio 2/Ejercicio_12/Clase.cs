﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    public static class Clase
    {
        public static bool validaS_N(char caracter)
        {
            if(caracter == 's')
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
