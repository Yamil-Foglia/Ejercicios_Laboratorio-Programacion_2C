﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 12";

            int contador = 0;
            int numero;
            char respuesta; 
            int acumulador = 0;

            do
            {
                Console.WriteLine("Numero {0}: ", contador + 1);
                while (!(int.TryParse(Console.ReadLine(), out numero)))
                {
                    Console.WriteLine("ERROR - Numero: ");
                    Console.ReadKey();
                }
                acumulador = acumulador + numero;
                contador++;

                Console.WriteLine("¿Continuar ? (S / N) ");

                char.TryParse(Console.ReadLine(), out respuesta);

            } while(Clase.validaS_N(respuesta));

            Console.WriteLine("La suma de los numeros ingresados es: {0}", acumulador);
            Console.ReadKey();
        }
    }
}
