﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    public class Punto
    {
        private int x;
        private int y;

        public Punto(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int GetX()
        {
            return this.x;
        }

        public int GetY()
        {
            return this.y;
        }
    }

    class Rectangulo
    {
        private float area;
        private float perimetro;
        private Punto vertice1;
        private Punto vertice2;
        private Punto vertice3;
        private Punto vertice4;


        public Rectangulo(Punto vertice1, Punto vertice3)
        {
            float alturaDelRectangulo = 0;
            float baseDelRectangulo = 0;

            int xVertice1 = vertice1.GetX();
            int yVertice1 = vertice1.GetY();
            int xVertice3 = vertice3.GetX();
            int yVertice3 = vertice3.GetY();

            int valorAbsolutoX1 = Math.Abs(xVertice1);
            int valorAbsolutoY1 = Math.Abs(yVertice1);
            int valorAbsolutoX3 = Math.Abs(xVertice3);
            int valorAbsolutoY3 = Math.Abs(yVertice3);

            if(yVertice3 == 0)
            {
                alturaDelRectangulo = yVertice1;
            }
            else if (yVertice3 < 0)
            {
                alturaDelRectangulo = yVertice1 + (yVertice3 * -1);
            }
            else if (yVertice3 > 0)
            {
                alturaDelRectangulo = yVertice1 - yVertice3;
            }


            if (xVertice1 == 0)
            {
                baseDelRectangulo = xVertice3;
            }
            else if(xVertice1 < 0)
            {
                baseDelRectangulo = xVertice1 + (xVertice3 * -1);
            }
            else if(xVertice1 > 0)
            {
                baseDelRectangulo = xVertice3 - xVertice1;
            }

            this.area = baseDelRectangulo * alturaDelRectangulo;
            this.perimetro = (baseDelRectangulo * alturaDelRectangulo) / 2;

        }
        public float Area()
        {
            return this.area;
        }

        public float Perimetro()
        {
            return this.perimetro;
        }
    }
}
