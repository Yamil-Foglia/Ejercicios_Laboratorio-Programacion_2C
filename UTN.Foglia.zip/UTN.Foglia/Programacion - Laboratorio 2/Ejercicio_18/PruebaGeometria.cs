﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Geometria;

namespace PruebaGeometria
{
    public static class Prueba
    {
        public static void MainSecundario()
        {
            Punto vertice1 = new Punto(0, 3);
            Punto vertice3 = new Punto(8, -3);

            Rectangulo rectangulo = new Rectangulo(vertice1, vertice3);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Area: {0}", rectangulo.Area());
            Console.WriteLine("Perimetro: {0}", rectangulo.Perimetro());
            MostrarParametrosDeRectangulo(vertice1, vertice3);
        }

        public static void MostrarParametrosDeRectangulo(Punto vertice1, Punto vertice3)
        {
            Console.WriteLine("\n\nParametros");
            Console.WriteLine("\n\nVertice 1: \nx: {0} y: {1}", vertice1.GetX(), vertice1.GetY());
            Console.WriteLine("\nVertice 3: \nx: {0} y: {1}", vertice3.GetX(), vertice3.GetY());
            Console.ReadKey();
        }
    }
}
