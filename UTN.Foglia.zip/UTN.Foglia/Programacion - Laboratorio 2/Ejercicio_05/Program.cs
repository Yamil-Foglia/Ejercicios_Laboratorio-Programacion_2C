﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_05
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 05";

            int numero;
            int i;
            int j;
            int flag = 1;
            int acumulador = 0;
            int numeroAnterior;
            int numeroProximo;


            while (flag == 1)
            {
                Console.WriteLine("Numero: ");

                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    Console.WriteLine("Exito - Numero ingresado {0}", numero);

                    for (i=2; i<=numero; i++)
                    {
                       for(j=i+1; j<numero; j++)
                       {
                            numeroAnterior = i - 1;
                            numeroProximo = i + 1;

                            if (numeroAnterior < numeroProximo)
                            {
                                numeroAnterior = numeroAnterior + 

                            }
                               
                       }
                    }
                    Console.ReadKey();
                    flag = 0;
                }
                else
                {
                    Console.WriteLine("ERROR. ¡Reingresar número!");
                }
            }
        }
    }
}
