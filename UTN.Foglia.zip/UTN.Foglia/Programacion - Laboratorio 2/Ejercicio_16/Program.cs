﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 16";

            string nombre;
            string apellido;
            int legajo;
            byte notaUno;
            byte notaDos;
            int i;
            Alumno[] nuevoAlumno = new Alumno[3];


            for (i=0; i<3; i++)
            {
                try
                {

                    Console.Write("\nAlumno {0}: ", i + 1);
                    Console.Write("\n\nNombre: ");
                    nombre = Console.ReadLine();

                    Console.Write("\nApellido: ");
                    apellido = Console.ReadLine();

                    Console.Write("\nLegajo: ", i + 1);
                    legajo = int.Parse(Console.ReadLine());

                    nuevoAlumno[i] = new Alumno(nombre, apellido, legajo);

                    Console.Write("\nNota 1: ");
                    notaUno = byte.Parse(Console.ReadLine());

                    Console.Write("\nNota 2: ");
                    notaDos = byte.Parse(Console.ReadLine());

                    nuevoAlumno[i].Estudiar(notaUno, notaDos);
                    nuevoAlumno[i].CalcularFinal();

                    Console.WriteLine(nuevoAlumno[i].Mostrar());
                    Console.ReadLine();
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(ex.Message);
                    Console.ReadLine();
                }
            }
            

        }
    }
}
