﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    public class Alumno
    {
        public byte notaUno;
        public byte notaDos;
        public float notaFinal;
        public string apellido;
        public int legajo;
        public string nombre;

        public Alumno(string nombre, string apellido, int legajo)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.legajo = legajo;
        }
        
        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.notaUno = notaUno;
            this.notaDos = notaDos;
            
        }

        public void CalcularFinal()
        {
            if(notaUno >= 4 && notaDos >= 4)
            {
                Random rdm = new Random((int)DateTime.Now.Ticks);

                this.notaFinal = rdm.Next(4, 10);
            }
            else
            {
                this.notaFinal = -1;
            }
        }

        public string Mostrar()
        {
            string mensaje;

            if (this.notaFinal == -1)
            {
                mensaje = "Alumno desaprobado";
            }
            else
            {
                mensaje = "El alumno " + this.nombre +" "+this.apellido +" aprobo el final con " + this.notaFinal;
            }

            return mensaje;
        }

    }
}
