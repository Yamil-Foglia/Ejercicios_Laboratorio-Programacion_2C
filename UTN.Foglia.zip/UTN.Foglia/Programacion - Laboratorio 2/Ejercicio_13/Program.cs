﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 13";

            double numero;
            string binario;

            double respuesta_decimal;
            string respuesta_binario = " ";

            Console.WriteLine("Decimal: ");
            while (!(double.TryParse(Console.ReadLine(), out numero)))
            {
                Console.WriteLine("ERROR - Decimal: ");
                Console.ReadKey();
            }
            respuesta_binario = Conversor.DecimalBinario(numero);


            Console.WriteLine("Decimal visto en binario: {0}", respuesta_binario);
            Console.ReadKey();

            Console.WriteLine("Binario: ");

            binario = Console.ReadLine();

            respuesta_decimal = Conversor.BinacioDecimal(binario);
            Console.WriteLine("Binario visto en decimal: {0}", respuesta_decimal);
            Console.ReadKey();

        }
    }
}
