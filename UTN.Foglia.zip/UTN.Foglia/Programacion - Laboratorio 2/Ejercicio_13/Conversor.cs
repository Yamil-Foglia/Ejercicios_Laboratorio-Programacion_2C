﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13
{
    public static class Conversor
    {
        public static string DecimalBinario(double numero)
        {
            string binario = "";

            int entero = (int)numero;

            while(entero > 0)
            {
                binario = entero % 2 + binario;
                entero = entero / 2;
            }

            return binario;
        }
        public static double BinacioDecimal(string binario)
        {
            double numero;
            int entero = Convert.ToInt32(binario, 2);

            numero = Convert.ToDouble(entero);

            return numero;
        }
    }
}
